<div class="container text-center">
    <img style="max-height: 75px; max-width:100%;" src="{{ asset('images/advertisement.jpg') }}" alt="{{ __('') }}">
</div>
